import React from 'react'

function PageNotFound() {
    return (
        <div>
            <h1>404 Not Found</h1>            
        </div>
    )
}

export default PageNotFound
